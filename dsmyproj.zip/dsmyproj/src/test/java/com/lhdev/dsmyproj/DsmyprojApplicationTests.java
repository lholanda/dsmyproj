package com.lhdev.dsmyproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsmyprojApplicationTests {

	@Test
	void contextLoads() {
	}

}
