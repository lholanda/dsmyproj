package com.lhdev.dsmyproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsmyprojApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsmyprojApplication.class, args);
	}

}
